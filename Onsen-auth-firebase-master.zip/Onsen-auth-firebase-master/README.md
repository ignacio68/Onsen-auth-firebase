# Onsen-auth-firebase
Desarrollo de las páginas de login y registro de usuario con autenticación en firebase en una app movil utilizando OnsenUI
